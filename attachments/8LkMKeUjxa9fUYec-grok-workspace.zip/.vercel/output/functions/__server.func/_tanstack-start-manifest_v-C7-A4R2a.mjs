//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C7-A4R2a.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/causes",
			"/cost",
			"/data",
			"/devices",
			"/lifetime",
			"/parts",
			"/repeats",
			"/report"
		],
		preloads: ["/assets/index-rQpJMqiw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-rQpJMqiw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D0pFvj__.js",
			"/assets/use-view-DpzUYcz-.js",
			"/assets/badge-CCPPmonI.js",
			"/assets/theme-cDQb2CSl.js",
			"/assets/kpi-card-Dz7MsaXM.js",
			"/assets/rank-table-DIZB04rE.js"
		]
	},
	"/causes": {
		filePath: "/workspace/src/routes/causes.tsx",
		children: void 0,
		preloads: [
			"/assets/causes-_DXmY0PO.js",
			"/assets/use-view-DpzUYcz-.js",
			"/assets/badge-CCPPmonI.js"
		]
	},
	"/cost": {
		filePath: "/workspace/src/routes/cost.tsx",
		children: void 0,
		preloads: [
			"/assets/cost-BjCM2C0P.js",
			"/assets/use-view-DpzUYcz-.js",
			"/assets/theme-cDQb2CSl.js",
			"/assets/kpi-card-Dz7MsaXM.js",
			"/assets/rank-table-DIZB04rE.js"
		]
	},
	"/data": {
		filePath: "/workspace/src/routes/data.tsx",
		children: void 0,
		preloads: [
			"/assets/data-_eyNMzh3.js",
			"/assets/use-view-DpzUYcz-.js",
			"/assets/badge-CCPPmonI.js"
		]
	},
	"/devices": {
		filePath: "/workspace/src/routes/devices.tsx",
		children: void 0,
		preloads: [
			"/assets/devices-DSxtnI_8.js",
			"/assets/use-view-DpzUYcz-.js",
			"/assets/rank-table-DIZB04rE.js"
		]
	},
	"/lifetime": {
		filePath: "/workspace/src/routes/lifetime.tsx",
		children: void 0,
		preloads: [
			"/assets/lifetime-wqWU5Qrm.js",
			"/assets/use-view-DpzUYcz-.js",
			"/assets/theme-cDQb2CSl.js"
		]
	},
	"/parts": {
		filePath: "/workspace/src/routes/parts.tsx",
		children: void 0,
		preloads: [
			"/assets/parts-eTq46_Dt.js",
			"/assets/use-view-DpzUYcz-.js",
			"/assets/badge-CCPPmonI.js"
		]
	},
	"/repeats": {
		filePath: "/workspace/src/routes/repeats.tsx",
		children: void 0,
		preloads: [
			"/assets/repeats-UzzBr7B2.js",
			"/assets/use-view-DpzUYcz-.js",
			"/assets/kpi-card-Dz7MsaXM.js"
		]
	},
	"/report": {
		filePath: "/workspace/src/routes/report.tsx",
		children: void 0,
		preloads: ["/assets/report-BTnpN-hL.js", "/assets/use-view-DpzUYcz-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
